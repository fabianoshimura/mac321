package toyfactory;

public class White implements Color {

    @Override
    public String getColor() {
        return "White";
    }

}
