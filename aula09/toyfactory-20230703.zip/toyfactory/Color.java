package toyfactory;

public interface Color {
    String getColor();
}
