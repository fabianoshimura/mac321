package toyfactory;

public class Brown implements Color {

    @Override
    public String getColor() {
        return "brown";
    }

}
