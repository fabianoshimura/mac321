package polígonos;

public interface Polygon {
    String getType();
    Polygon clone();
}
