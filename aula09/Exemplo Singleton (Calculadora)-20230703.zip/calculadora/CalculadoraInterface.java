public interface CalculadoraInterface<T extends Number> {

    public void exibeResultado();
    public void soma(T x, T y);
}
