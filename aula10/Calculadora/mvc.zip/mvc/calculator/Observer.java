package mvc.calculator;

public interface Observer {
    void update();
}
