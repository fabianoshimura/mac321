
public class HelloWorldNão {
	public static void main (String[] args) {
	      System.out.println("Qualquer coisa menos Hello World!");
	   }
	
	
}
