//import java.util.Date;

public class HWConta {
    public static void main(String[] args) {
        System.out.println("Hello, world!");
	    float x = (float) 1/41;
	    x *= 41;
	    System.out.println(x);
    }

}
