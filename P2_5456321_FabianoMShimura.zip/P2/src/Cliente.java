import model.carona.Viagem;
import model.carona.ViagemAceitandoState;
import model.carona.ViagemAndamentoState;
import model.carona.ViagemConcluidaState;

public class Cliente {

    public static void main(String[] args) {

        // Instancia um novo registrador. Obs: O registrador eh unico
        // Usa-se o padrão Singleton para registrador

        Registrador registrador = Registrador.getInstance();

        // MOTORISTA registra viagem
        registrador.registrarViagem("Rua do Matão", "Estação Butantã", 10);
        registrador.registrarViagem("Av, Paulista 1000", "Av. Comendador Bonfiglioli, 100", 45);
        registrador.registrarViagem("Rua Bodocongo, 0", "Casa da mae Joana, 100", 32);
        registrador.registrarViagem("Rua Sei La, 896", "La Sei, 698", 21);

        // OUTRO USUARIO (passageiro) procura por caronas

        registrador.buscarViagem("Rua Bodocongo, 0", "Casa da mae Joana, 100");

        // MOTORISTA altera o status da viagem #3

        registrador.mostrarStatusViagem(3);

        //registrador.mudarStatusViagem(3, ViagemAceitandoState.aceitarViagem());

        registrador.mostrarStatusViagem(3);

        // MOTORISTA mostra preco da viagem inserindo o Id da viagem, depois de concluir

        //registrador.mudarStatusViagem(3, ViagemAndamentoState.finalizarViagem());
        registrador.precoViagem(3);

        // ADMINISTRADOR gera relatório completo
        registrador.listarViagens();
        registrador.quantiaMovimentada();

    }
}
